import tkinter as tk
from tkinter import messagebox
import pandas as pd
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.ensemble import RandomForestRegressor
import joblib

# Load your dataset (replace this with your actual dataset loading code)
# Assuming your dataset is stored in a variable called 'data'
data = pd.read_csv("Data RSL.csv")  # Update with your dataset file path

# Extract necessary columns for prediction
selected_columns = ['Revenue category', 'Year', 'Value']
data = data[selected_columns]

# Assuming 'Value' is the tax revenue column and 'Year' is the target year
# Feature Engineering (if needed)
# Encoding categorical feature
label_encoder = LabelEncoder()
data['Revenue category'] = label_encoder.fit_transform(data['Revenue category'])

# Split the data into features and target variable
X = data.drop(columns=['Value'])
y = data['Value']

# Scale the numerical features (if needed)
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Train a RandomForestRegressor model
model = RandomForestRegressor(random_state=42)
model.fit(X_scaled, y)

# Save the model
joblib.dump(model, 'tsepo.joblib')

# Create Tkinter application window
window = tk.Tk()
window.title("Revenue Prediction Dashboard")

# Function to handle prediction
def predict_value():
    try:
        # Get input values from entry fields
        revenue_category = entry_category.get()
        year = int(entry_year.get())

        # Encode the 'Revenue category' using the LabelEncoder
        revenue_category_int = label_encoder.transform([revenue_category])[0]

        # Create a DataFrame with the user input
        new_data = pd.DataFrame({'Revenue category': [revenue_category_int], 'Year': [year]})

        # Scale the numerical features using the StandardScaler
        new_data_scaled = scaler.transform(new_data)

        # Make prediction
        predicted_value = model.predict(new_data_scaled)

        # Display predicted value
        result_label.config(text="Predicted revenue value: {:.2f}".format(predicted_value[0]))

    except Exception as e:
        messagebox.showerror("Error", str(e))

# Create labels and entry fields for user input
label_category = tk.Label(window, text="Revenue Category:")
label_category.grid(row=0, column=0, padx=10, pady=5)
entry_category = tk.Entry(window)
entry_category.grid(row=0, column=1, padx=10, pady=5)

label_year = tk.Label(window, text="Year:")
label_year.grid(row=1, column=0, padx=10, pady=5)
entry_year = tk.Entry(window)
entry_year.grid(row=1, column=1, padx=10, pady=5)

# Button to trigger prediction
predict_button = tk.Button(window, text="Predict", command=predict_value)
predict_button.grid(row=2, column=0, columnspan=2, padx=10, pady=10)

# Label to display predicted value
result_label = tk.Label(window, text="")
result_label.grid(row=3, column=0, columnspan=2, padx=10, pady=5)

# Start the Tkinter event loop
window.mainloop()
