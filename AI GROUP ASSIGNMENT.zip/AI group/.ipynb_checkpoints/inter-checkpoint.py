{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 1,
   "id": "834a42f0-2ba1-44fa-ad56-e5e6f6ae131d",
   "metadata": {},
   "outputs": [
    {
     "data": {
      "application/vnd.jupyter.widget-view+json": {
       "model_id": "a50d53cc023049cf8a3deb24414dcafc",
       "version_major": 2,
       "version_minor": 0
      },
      "text/plain": [
       "VBox(children=(Text(value='', description='Revenue Category:'), IntSlider(value=2022, description='Year:', max…"
      ]
     },
     "metadata": {},
     "output_type": "display_data"
    }
   ],
   "source": [
    "import ipywidgets as widgets\n",
    "from IPython.display import display\n",
    "from joblib import load\n",
    "\n",
    "# Load the trained model\n",
    "model = load('tax_revenue_prediction_model.joblib')\n",
    "\n",
    "# Create widgets for input\n",
    "revenue_category = widgets.Text(description=\"Revenue Category:\")\n",
    "year = widgets.IntSlider(description=\"Year:\", min=2004, max=2024, step=1, value=2022)\n",
    "predict_button = widgets.Button(description=\"Predict\")\n",
    "\n",
    "# Function to perform prediction\n",
    "def predict_revenue(_):\n",
    "    prediction = model.predict([[year.value]])[0]\n",
    "    result_label.value = f\"Predicted Revenue for {revenue_category.value} in {year.value}: {prediction:.2f} Millions\"\n",
    "\n",
    "predict_button.on_click(predict_revenue)\n",
    "\n",
    "# Create a label for displaying the prediction result\n",
    "result_label = widgets.Label()\n",
    "\n",
    "# Arrange the widgets using a VBox\n",
    "input_widgets = widgets.VBox([revenue_category, year, predict_button, result_label])\n",
    "\n",
    "# Display the widgets\n",
    "display(input_widgets)\n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": None,
   "id": "69158ce0-39ed-4576-a9ec-2d0c9cc69724",
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3 (ipykernel)",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.11.7"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
